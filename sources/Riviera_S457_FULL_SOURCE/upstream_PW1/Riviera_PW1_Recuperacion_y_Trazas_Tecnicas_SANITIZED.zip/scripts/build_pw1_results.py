from pathlib import Path
import csv, json, hashlib, glob, re, shutil
ROOT=Path('pw1')
OUT=ROOT/'deliverables'; OUT.mkdir(parents=True,exist_ok=True)
ROM=Path('pw1/source_current/Riviera_S457_FULL_SOURCE/build/Riviera_v0110_S457_rebuilt.wsc').read_bytes()
rom_sha=hashlib.sha256(ROM).hexdigest()

# RIBBON-22: join the S445 alias spec with the native 2064-record skill table.
alias=json.load(open('pw1/nested_hits/11_S445_fbd9fe84d012_RIBBON_ALIASES.json'))
skill_path=glob.glob('pw1/source_current/Riviera_S457_FULL_SOURCE/**/S444/Riviera_S444_FULL_SOURCE/analysis/SKILL_CENSUS.json',recursive=True)[0]
skill=json.load(open(skill_path)); byptr={}
for rec in skill['records']: byptr.setdefault(rec['pointer'].upper(),[]).append(rec)
rows=[]
for a in alias:
    ptr=a['pointer'].upper(); recs=byptr[ptr]
    owners=[0x651190+r['id']*22 for r in recs]
    assert all(ROM[o:o+2]==int(ptr,16).to_bytes(2,'little') for o in owners)
    pat=b'\x81\xff'+int(ptr,16).to_bytes(2,'little')
    dispatch=[]; p=0
    while True:
        p=ROM.find(pat,p)
        if p<0: break
        # S445's dedicated 22-way ribbon dispatcher occupies D810..D92E.
        # E2C8 also has an older, separate spacing comparison at D689.
        if 0x72D810<=p<0x72D930: dispatch.append(p)
        p+=1
    assert len(dispatch)==1,(ptr,dispatch)
    d=dispatch[0]
    assert ROM[d+4]==0x75 and ROM[d+6]==0xBF
    target=int.from_bytes(ROM[d+7:d+9],'little')
    rows.append({
      'pointer':ptr,'canonical':a['canonical'],'ribbon':a['ribbon'],'width':a['width'],
      'owner_record_ids':';'.join(str(r['id']) for r in recs),
      'owner_fields_physical':';'.join(f'0x{o:06X}' for o in owners),
      'owner_field_count':len(owners),'categories':';'.join(str(r['category']) for r in recs),
      'dispatcher_compare_physical':f'0x{d:06X}','alias_target_runtime':f'0x{target:04X}',
      'consumer':'RIV-CONS-72D000 / action_name native ribbon','current_rom_pointer_match':True,
      'runtime_basis':'S445 all_actions 561/561; outside_rectangle=0; fallbacks=0'
    })
with open(OUT/'RIBBON_22_OWNER_MAP.csv','w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
json.dump({'gate':'RIBBON-22','result':'PASS','rom_sha256':rom_sha,'aliases':22,
 'owner_fields_total':sum(r['owner_field_count'] for r in rows),'native_table':{'start':'0x651190','stride':22,'slots':2064},
 'dispatcher_region':'0x72D000','static_checks':{'all_owner_fields_match':True,'all_22_dispatch_compares_unique':True},
 'runtime_inherited':{'stage':'S445','all_actions':561,'outside_rectangle':0,'fallbacks':0,'alias_visual_montage':'ALIAS_22.png'},
 'note':'Each alias pointer is linked to every original skill-table field that owns it; duplicate owners are preserved.'},open(OUT/'RIBBON_22_RESULT.json','w'),ensure_ascii=False,indent=2)

# A364: prove exact 0..119 owner envelope, one loader and one far callsite.
a364=json.load(open('pw1/nested_hits/16_S440_70dbf54084c8_S437_A364_34_STATIC_SUMMARY.json'))
entries={}; pointer_to_resource={}
resource_rows=[]
for res in a364['resources']:
    ptr_details=res['pointer_details']
    idxs=[]
    for d in ptr_details:
        phys=int(d['physical'],16); idx=(phys-0x4654D4)//2
        assert phys==0x4654D4+idx*2 and 0<=idx<120 and d['ok']
        assert phys not in entries
        entries[phys]={'index':idx,'resource_id':res.get('resource_id') or res.get('id'),'english':res.get('english'),'expected':d['expected'],'actual':d['actual']}
        pointer_to_resource.setdefault(d['expected'], (res.get('resource_id') or res.get('id'), res.get('english')))
        idxs.append(idx)
    resource_rows.append({'resource_id':res.get('resource_id') or res.get('id'),'english':res.get('english'),'indices':idxs})
# S437 declared 117 owner fields; indices 9..11 repeat the same A364[08]
# pointer and are recovered directly from the contiguous native table.
assert len(entries)==117
for idx in range(120):
    phys=0x4654D4+idx*2
    if phys in entries: continue
    actual=ROM[phys:phys+2].hex()
    rid,english=pointer_to_resource[actual]
    entries[phys]={'index':idx,'resource_id':rid,'english':english,'expected':actual,'actual':actual,'recovered_contiguous':True}
assert len(entries)==120 and sorted(x['index'] for x in entries.values())==list(range(120))
loader=bytes.fromhex('b00ce6c080eb0632ffd1e356b800608ed8bed4548b309ae2240020')
loader_hits=[];p=0
while True:
 p=ROM.find(loader,p)
 if p<0:break
 loader_hits.append(p);p+=1
assert loader_hits==[0x72A34E],loader_hits
callpat=bytes.fromhex('9a4ea30020'); callhits=[];p=0
while True:
 p=ROM.find(callpat,p)
 if p<0:break
 callhits.append(p);p+=1
assert callhits==[0x75CBCB],callhits
json.dump({'gate':'A364-ENVELOPE','result':'PASS','rom_sha256':rom_sha,
 'table':{'physical_start':'0x4654D4','entry_size':2,'index_min':0,'index_max':119,'entries':120,'last_owner_field':'0x4655C2','coverage_exact_0_119':True},
 'selector':{'loader_physical':'0x72A34E','operations':['SUB BL,0x06','XOR BH,BH','SHL BX,1','DS=0x6000','SI=0x54D4','MOV SI,[BX+SI]','LCALL 2000:24E2'],'relation':'index = input_BL - 6','unique_loader_signature':True,'unique_far_callsite_physical':'0x75CBCB'},
 'assets':{'unique_streams':34,'static_exact':34,'owner_fields_checked':120,'runtime_forced_render_passes':34,'runtime_note':'All unique resources traversed through the real loader/consumer; natural encounter coverage remains separate.'},
 'resources':resource_rows},open(OUT/'A364_ENVELOPE_RESULT.json','w'),ensure_ascii=False,indent=2)

# I04 bounded negative trace on current S457.
block=ROM[0x6CACBE:0x6CAEBE]; assert len(block)==512
low=bytes.fromhex('beac'); hits=[];p=0
while True:
 p=ROM.find(low,p)
 if p<0:break
 hits.append(p);p+=1
exact=[];p=0
while True:
 p=ROM.find(block,p)
 if p<0:break
 exact.append(p);p+=1
refs={'BE AC 6C':bytes.fromhex('beac6c'),'6C BE AC':bytes.fromhex('6cbeac')}
ref_counts={k:ROM.count(v) for k,v in refs.items()}
i04={'gate':'I04-6C-TECH','result':'NOT_VALIDATED','rom_sha256':rom_sha,
 'candidates':[{'id':'CP932-15939','interval':'0x6CAE90..0x6CAE99'},{'id':'CP932-15968','interval':'0x6CAD76..0x6CAD81'}],
 'containing_block':'0x6CACBE..0x6CAEBE','block_bytes':512,'exact_block_hits':[f'0x{x:06X}' for x in exact],
 'lowword_ACBE_hits':[f'0x{x:06X}' for x in hits],'direct_far_reference_counts':ref_counts,
 'known_consumer':{'copies':8,'index_8_probe_transfers':0,'sentinel_512_unchanged':True},
 'current_controlled_routes':{'candidate_hits':0},
 'disposition':'No positive consumer and no global disuse proof. Data visually/structurally resembles a ninth icon, but the gate remains open without changing ROM.'}
json.dump(i04,open(OUT/'I04_6C_TRACE_RESULT.json','w'),ensure_ascii=False,indent=2)

# Readings: bounded research disposition.
readings={'gate':'I05-READINGS','result':'NOT_VALIDATED','date':'2026-09-24','limit':'bounded primary-source search',
 'entries':[{'japanese':'高津 利恵','credit':'Special Thanks, page 10 row 1','status':'READING_UNVERIFIED'},
            {'japanese':'深尾 伸也','credit':'Tuning, page 8 row 3','status':'READING_UNVERIFIED'},
            {'japanese':'橋本 信之','credit':'Special Thanks, page 9 row 3','status':'READING_UNVERIFIED'}],
 'sources_checked':[{'url':'https://www.sting.co.jp/','type':'official developer site','outcome':'Riviera product presence; no identity-linked reading for the three credit entries located'},
                    {'url':'https://www.mobygames.com/game/19619/riviera-the-promised-land/credits/wonderswan-color/','type':'secondary credits index','outcome':'Useful identity/context lead only; rejected as primary reading proof'}],
 'rejected_homonyms':['高津利恵 web/design and publishing pages without Riviera identity link','深尾伸也 non-game business profiles','橋本信之 academic/business profiles'],
 'action':'Preserve original Japanese pixels; do not insert inferred romanizations.'}
json.dump(readings,open(OUT/'I05_READINGS_RESULT.json','w'),ensure_ascii=False,indent=2)

# Exact PW2 inputs.
pw2={'iteration':'PW2','goal':'CORPUS-1436 and automated QA matrix','rom_sha256':rom_sha,'inputs':[
 {'role':'resource universe','path':'S455/analysis/B2/RESOURCES_CURRENT.json','local_evidence':'pw1/nested_hits/01_S455_Riviera_S455_FULL_SOURCE__analysis__B2__RESOURCES_CURRENT.json'},
 {'role':'use/consumer edges','path':'S455/analysis/B2/I03_USES.json','local_evidence':'pw1/nested_hits/01_S455_cc9bea02ba19_I03_USES.json'},
 {'role':'pointer checks','path':'S455/analysis/B2/POINTER_CHECKS.json','local_evidence':'pw1/nested_hits/01_S455_8f4b628c5022_POINTER_CHECKS.json'},
 {'role':'context queue','path':'S455/analysis/B2/OWNERS_REQUIRING_CONTEXT.json','local_evidence':'pw1/nested_hits/01_S455_Riviera_S455_FULL_SOURCE__analysis__B2__OWNERS_REQUIRING_CONTEXT.json'},
 {'role':'current ROM','path':'build/Riviera_v0110_S457_rebuilt.wsc','sha256':rom_sha},
 {'role':'cumulative BPS','path':'patches/Riviera_CLEAN_JP_to_v0110_S457_cumulative.bps','sha256':'e4bda7c628316fb92978f33ffc136c7f480f2a885f0b606be46e09b7c2335cef'},
 {'role':'PW1 exclusions/results','paths':['RIBBON_22_OWNER_MAP.csv','A364_ENVELOPE_RESULT.json','I04_6C_TRACE_RESULT.json','I05_READINGS_RESULT.json']}
 ],'required_outputs':['1436-row stable CSV/JSON','proof Bank66 595 is a subset','automated residual/pointer/overflow/orphan queues','manual review capped at 60']}
json.dump(pw2,open(OUT/'PW2_EXACT_INPUTS.json','w'),ensure_ascii=False,indent=2)

# Consolidated gate machine-readable result.
gates={'iteration':'PW1','status':'COMPLETED','consumed':'1/5','rom_changed':False,'rom_sha256':rom_sha,
 'results':[{'gate':'SOURCE_IDENTITY','result':'PASS'},{'gate':'A364-ENVELOPE','result':'PASS'},{'gate':'RIBBON-22','result':'PASS'},{'gate':'I04-6C-TECH','result':'NOT_VALIDATED'},{'gate':'I05-READINGS','result':'NOT_VALIDATED'}],
 'next_iteration':'PW2','high_score':'DEFERRED_OUT_OF_SCOPE'}
json.dump(gates,open(OUT/'PW1_GATE_RESULTS.json','w'),ensure_ascii=False,indent=2)
