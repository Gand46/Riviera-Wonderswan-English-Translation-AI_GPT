# Riviera Work Pt1.5 — PW1 Recuperación y trazas técnicas

**Fecha:** 2026-09-24  
**Estado:** `PW1 COMPLETADA` — presupuesto consumido `1/5`  
**Binario modificado:** no  
**Siguiente etapa:** `PW2 — Corpus 1.436 y auditoría automatizada`

## 1. Resultado ejecutivo

PW1 recuperó el árbol fuente y la evidencia necesaria, reconstruyó S457 desde la cadena histórica, aplicó el BPS acumulativo directamente a la ROM japonesa limpia y obtuvo el mismo binario objetivo en ambos caminos.

| Puerta | Resultado PW1 | Decisión |
| --- | --- | --- |
| Identidad fuente/BPS | `PASS` | Reconstrucción y BPS producen S457 byte-exacto. |
| A364-ENVELOPE | `PASS` | Tabla nativa completa 0–119, relación `índice = BL - 6`, cargador y único llamador identificados; 34 recursos únicos conservan verificación estática y ejecución controlada. |
| RIBBON-22 | `PASS` | Los 22 alias se enlazaron con sus campos propietarios originales, comparaciones compiladas, destinos de alias y consumidor nativo. |
| I04-6C-TECH | `NOT_VALIDATED` | Los dos intervalos pertenecen visualmente al bloque candidato de 512 bytes, pero no apareció consumidor positivo ni prueba global de desuso. |
| I05-READINGS | `NOT_VALIDATED` | No apareció una fuente primaria inequívoca que una lectura, identidad y crédito de Riviera para los tres nombres. Se preservan los kanji. |

High Score permanece `DEFERRED` y fuera del presupuesto de esta ruta.

## 2. Identidad reproducible

| Entrada o resultado | SHA-256 |
| --- | --- |
| ROM japonesa limpia | `62f3886d3bae02105e56677ae7f5efe77ff7cb47036d2955ca46ea4a3f712921` |
| S456 reconstruida | `b6ae03cda1be9d1742ca7aae3cfc32fe389c3fd51e9e3bc5b4929ff3653dcdc1` |
| S457 reconstruida | `80ff36655d83956d96b634adafc685fa4379da326c3d45099dedcb73ef72a951` |
| S457 producida por BPS | `80ff36655d83956d96b634adafc685fa4379da326c3d45099dedcb73ef72a951` |
| BPS acumulativo | `e4bda7c628316fb92978f33ffc136c7f480f2a885f0b606be46e09b7c2335cef` |
| Paquete fuente S457 recuperado | `bdc9d6ba52c5004f465f89751aef5207624dec3a1204c070a86bf18a928cdd69` |

`verify_s457.py` terminó con `S457_VERIFY_OK`. El checksum WonderSwan sigue en `0xD44D`, tamaño 8 MiB. La aplicación BPS valida CRC de origen, destino y parche.

Se recuperaron los cinco estados seleccionados posteriores a R6 y su `.sav` nativo. La contabilidad permanece en **44 históricos + 5 posteriores = 49 puntos seleccionados**; los `.mss` de diagnóstico duplicados no se promueven artificialmente al catálogo.

## 3. A364-ENVELOPE

La tabla empieza en físico `0x4654D4` y contiene exactamente **120 palabras**: índices `0..119`, último campo en `0x4655C2`. Los 34 valores de puntero únicos corresponden a los 34 recursos gráficos ya integrados. La auditoría heredada declaraba 117 campos; PW1 recuperó los índices 9–11 como repeticiones contiguas del puntero de `A364[08]`, completando la cobertura sin inventar entradas.

El cargador único está en físico `0x72A34E`:

1. resta `0x06` a `BL`;
2. limpia `BH` y multiplica por dos;
3. fija `DS=0x6000`, base `SI=0x54D4`;
4. lee `SI=[BX+SI]`;
5. llama al descompresor `2000:24E2`.

La única llamada lejana a ese cargador está en `0x75CBCB`. Esto establece la relación del selector y el sobre completo de la tabla. La evidencia S438 conserva 34/34 pasadas por el cargador/consumidor real y nombres completos; esas pasadas son forzadas y no equivalen a 34 encuentros naturales.

## 4. RIBBON-22

La tabla nativa de habilidades ocupa `0x651190..0x65C2F0`, tiene 2.064 registros de 22 bytes y guarda el puntero del nombre en los dos primeros bytes de cada registro. PW1 enlazó cada uno de los 22 punteros de `RIBBON_ALIASES.json` con todos sus campos propietarios originales. El mapa conserva propietarios duplicados: **22 alias, 64 campos propietarios**.

El dispatcher compilado de alias está en `0x72D810..0x72D92E`. Cada puntero tiene una comparación `CMP DI, imm16` única dentro del dispatcher y un destino de texto abreviado. El consumidor es `RIV-CONS-72D000 / action_name`.

La evidencia heredada S445 ejecutó los **561 nombres distintos** por el consumidor real: 561 llamadas, cero escrituras fuera del rectángulo y cero retornos al renderizador alternativo. El montaje `ALIAS_22.png` cubre los 22 casos. Con propietario, sustitución y consumidor conciliados, RIBBON-22 pasa.

## 5. I04-6C-TECH

Los intervalos abiertos siguen siendo:

- `CP932-15939`: `0x6CAE90..0x6CAE99`;
- `CP932-15968`: `0x6CAD76..0x6CAD81`.

Ambos caen dentro de `0x6CACBE..0x6CAEBE`, un bloque de 512 bytes con apariencia de noveno icono. En S457:

- el bloque completo aparece una sola vez;
- la palabra baja `ACBE` aparece 14 veces, sin referencia validada;
- no aparecen codificaciones directas `BE AC 6C` ni `6C BE AC`;
- el consumidor conocido copia ocho iconos;
- la sonda del índice 8 produjo cero transferencias y conservó intacto el buffer centinela;
- las rutas controladas acumuladas no registraron lecturas de los dos intervalos.

La ausencia de referencia directa y de lecturas acotadas no demuestra desuso global: siguen posibles referencias calculadas, alias del mapeador o consumidores tardíos. I04 permanece `NOT_VALIDATED`; no se toca la ROM.

## 6. I05-READINGS

La búsqueda primaria acotada no encontró una fuente que identifique de forma inequívoca a las personas de estos créditos y publique su lectura:

| Crédito | Estado |
| --- | --- |
| 高津 利恵 — Special Thanks, página 10 fila 1 | `READING_UNVERIFIED` |
| 深尾 伸也 — Tuning, página 8 fila 3 | `READING_UNVERIFIED` |
| 橋本 信之 — Special Thanks, página 9 fila 3 | `READING_UNVERIFIED` |

Se descartaron perfiles homónimos sin vínculo con Riviera. El índice secundario de créditos sirvió como pista de contexto, pero no satisface el requisito de fuente primaria. Las tres filas conservan los píxeles japoneses originales y no se insertan romanizaciones inferidas.

## 7. Entradas exactas de PW2

PW2 debe partir de:

- `RESOURCES_CURRENT.json`: universo actual de recursos;
- `I03_USES.json`: aristas recurso–uso–consumidor;
- `POINTER_CHECKS.json`: comprobaciones de campos propietarios;
- `OWNERS_REQUIRING_CONTEXT.json`: cola heredada que debe reconciliarse;
- ROM S457 exacta y BPS acumulativo verificado;
- resultados PW1, excluyendo A364 y RIBBON-22 de la cola abierta y manteniendo I04/I05 como pendientes con evidencia explícita.

Salidas obligatorias de PW2: índice estable de 1.436 filas, prueba de que Bank66/595 es subconjunto, colas automáticas de residuales/punteros/overflow/huérfanos y revisión manual máxima de 60 casos.

## 8. Archivos de evidencia

- `PW1_GATE_RESULTS.json`
- `RIBBON_22_OWNER_MAP.csv` y `RIBBON_22_RESULT.json`
- `A364_ENVELOPE_RESULT.json`
- `I04_6C_TRACE_RESULT.json`
- `I05_READINGS_RESULT.json`
- `SAVESTATE_CATALOG_PW1.json`
- `PW2_EXACT_INPUTS.json`
- `BINARY_HASHES.txt`, `BPS_APPLY.json` y `VERIFICATION_S457.json`

PW1 no genera una ROM nueva ni un BPS distinto. La salida cambia el estado de auditoría de A364 y RIBBON-22; conserva I04 e I05 abiertos con límites concretos.
